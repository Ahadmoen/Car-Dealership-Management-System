// #include<iostream> 
// #include<stdlib.h> 
// using namespace std; 
// void adminLogin()
// {
// 	int i;
// 	system("cls");
// 	system("Color 0B");
// 	cout<<"********************************************************************"<<endl;
// 	cout<<"**    ***        ******      *       *      ******      *      *  **"<<endl;
// 	cout<<"**   *   *       *     *     **     **         *        **     *  **"<<endl;
// 	cout<<"**  *     *      *     *     * *   * *         *        * *    *  **"<<endl;
// 	cout<<"**  *******      *     *     *  * *  *         *        *  *   *  **"<<endl;
// 	cout<<"**  *     *      *     *     *   *   *         *        *   *  *  **"<<endl;
// 	cout<<"**  *     *      ******      *       *      ******      *    * *  **"<<endl;
// 	cout<<"********************************************************************"<<endl;
// 	cout<<endl<<endl;
// 	cout<<"Please select an option to continue..."<<endl;
// 	cout<<"1-Add a Car"<<endl;
// 	cout<<"2-Show all Cars"<<endl;
// 	cout<<"3-Sell a Car"<<endl;
// 	cout<<"4-Check Showroom Capacity"<<endl;
// 	cin>>i;
// 	while(i<=0 || i>=5)
// 	{
// 		cout<<"You have entered a wrong option..."<<endl;
// 		cout<<"Please select an avaliable option(1-4) to continue"<<endl;
// 		cin>>i;
// 	}
// 	switch(i)
// 	{
// 		case 1:
// 			addCar();
// 			break;
// 		case 2:
// 			showAllCars();
// 			break;
// 		case 3:
// 			sellCar();
// 			break;
// 		case 4:
// 			showCapacity();
// 			break;
// 	}
// }
// int main()
// {
// 	adminLogin();
// }
